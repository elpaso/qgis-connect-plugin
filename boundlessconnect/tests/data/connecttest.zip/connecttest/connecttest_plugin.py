# -*- coding: utf-8 -*-

import os

from PyQt4.QtGui import QAction
from qgis.gui import QgsMessageBar


class ConnectTestPlugin:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        self.actionRun = QAction('Connect Test', self.iface.mainWindow())
        self.iface.addPluginToMenu('Connect Test', self.actionRun)
        self.actionRun.triggered.connect(self.run)

    def unload(self):
        self.iface.removePluginMenu('Connect Test', self.actionRun)

    def run(self):
        self.iface.messageBar().pushInfo('Greeting', 'Hello, from Connect Test plugin!')
