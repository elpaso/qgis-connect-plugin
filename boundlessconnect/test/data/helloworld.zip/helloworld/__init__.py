# -*- coding: utf-8 -*-

def classFactory(iface):
    from helloworld_plugin import HelloWorldPlugin
    return HelloWorldPlugin(iface)
