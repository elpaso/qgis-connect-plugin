# -*- coding: utf-8 -*-

import os

from PyQt4.QtGui import QAction
from qgis.gui import QgsMessageBar


class HelloWorldPlugin:
    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        self.actionRun = QAction('Hello World', self.iface.mainWindow())
        self.iface.addPluginToMenu('Hello World', self.actionRun)
        self.actionRun.triggered.connect(self.run)

    def unload(self):
        self.iface.removePluginMenu('Hello World', self.actionRun)

    def run(self):
        self.iface.messageBar().pushInfo('Greeting', 'Hello, World!')
